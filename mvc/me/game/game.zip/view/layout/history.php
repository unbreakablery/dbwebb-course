<?php

/**
 * Layout to generate a page useful for debug.
 */

declare(strict_types=1);

require __DIR__ . "/../header.php";
require __DIR__ . "/../dice-history.php";
require __DIR__ . "/../footer.php";
