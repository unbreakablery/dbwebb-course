<?php

/**
 * Standard layout to generate a web page.
 */

declare(strict_types=1);

require __DIR__ . "/../header.php";
require __DIR__ . "/../dice.php";
require __DIR__ . "/../footer.php";
