<?php

define("INSTALL_PATH", 1);
